package hs.struct;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class ParserPart {
	ArrayList<String> causeList = new ArrayList<String>();
	String result = "";
	
	ArrayList<String> senseList = new ArrayList<String>();
	
	/*
	 * {(a,b)-A} �� ���� �� �ٸ� �Ľ��Ѵ�
	 */
	public void oneline(String line) {
		StringTokenizer str = new StringTokenizer(line,"{}()-");
		String causeLine = "";
		String resultLine = "";
		
		int count = str.countTokens();
		
		if (str.hasMoreTokens()) {
			causeLine = str.nextToken();
		}
		
		if (str.hasMoreTokens()) {
			resultLine = str.nextToken();
		}
		
		str = new StringTokenizer(causeLine,",");
		while (str.hasMoreElements()) {
			causeList.add(str.nextToken());
		}
		
		result = resultLine;
		
		System.out.println("causeList=" + causeList);
		System.out.println("resultLine=" + resultLine);
	}
	
	/*
	 * (a,b) �� ���� ���� ������ �Ľ��Ѵ�.
	 */
	public void onelineSensing(String line) {
		StringTokenizer str = new StringTokenizer(line,"()");
		String senseLine = "";

		if (str.hasMoreTokens()) {
			senseLine = str.nextToken();
		}

		str = new StringTokenizer(senseLine,",");
		while (str.hasMoreElements()) {
			senseList.add(str.nextToken());
		}

		System.out.println("senseList=" + senseList);
	}
}
