package hs.struct;

/*
 * ��ǥ�� ���� ��
 * 
 * target ��ǥ
 * force ��
 */
public class Vector {
	Node target;
	float force;
	
	public void init() {
		target = null;
		force = 0.0f;
	}
	
	public void init(Node target, float force) {
		this.target = target;
		this.force = force;
	}
}
