package hs.struct;

public class Print {

	public void printDot(Convergence cg) {
		String nodeAttr = "";
		
		System.out.println("digraph G {");
		System.out.println("    rankdir = BT;");
		
		for (Node ob : cg.inList) {
			System.out.print("    " + ob.getName());
			if (ob.getState() == true) {
				System.out.print(" [color=red]");
			}
			System.out.println(";");
		}
		
		for (Node ob : cg.outList) {
			System.out.println("    " + ob.getName() + ";");
		}

		for (Node ob : cg.conList) {
			System.out.println("    " + ob.getName() + ";");
		}
		
		// �Է³�� - �������� ��ũ
		for (Node ob : cg.inList) {
			for (Link nk : ob.upList) {
				Node ob2 = nk.to;
				if (nk.getForce()>0) {
					nodeAttr = "[label=" + String.valueOf(nk.getForce()) + "]";
				}
				System.out.println("    " + ob.getName() + " -> " + ob2.getName() + " " + nodeAttr + ";");
			}
		}
		
		// ������ - ������/��³�� ��ũ
		for (Node ob : cg.conList) {
			for (Link nk : ob.upList) {
				Node ob2 = nk.to;
				if (nk.getForce()>0) {
					nodeAttr = "[label=" + String.valueOf(nk.getForce()) + "]";
				}
				System.out.println("    " + ob.getName() + " -> " + ob2.getName() + " " + nodeAttr + ";");
			}
		}
		
		System.out.println("}");
	}
}
