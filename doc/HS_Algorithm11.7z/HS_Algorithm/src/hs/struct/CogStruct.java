package hs.struct;

import java.util.ArrayList;

/*
 * 
	1. �ε� CogStruct.load();
	2. �Է� CogStruct.input();
	3. �н� Cognize
		3.1 �������� CogStruct.add()
		3.2 ��������ȭ CogStruct.merge()
		3.3 ����ġ����ȭ CogStruct.adjust()
	4. ���� Recognize
		4.1 ��� CogStruct.recog()
	5. ����
		5.1 ���� OK -> �������� CogStruct.save()
		5.2 ���� Not OK -> ���� case ����
 */
public class CogStruct {

	Convergence cg = null;
	ParserPart part = new ParserPart();;
	
	public void load() {
		System.out.println("CogStruct.load()");
		
		cg = new Convergence();
	}
	
	public void inputEvent(String event) {
		System.out.println("CogStruct.inputEvent()");
		System.out.println("event=" + event);
		
		part.oneline(event);
	}
	
	public void inputSense(String sense) {
		System.out.println("CogStruct.inputSense()");
		System.out.println("sense=" + sense);
		
		part.onelineSensing(sense);
	}
	
	public void add() {
		System.out.println("CogStruct.add()");
		
		// 1. cause node
		for (String str : part.causeList) {
			System.out.println("cause=" + str);
			
			Node ob = new Node(str);
			cg.addInNode(ob);
		}
		
		// 2. result node
		Node obOut = new Node(part.result);
		cg.addOutNode(obOut);
		System.out.println("result=" + part.result);
		
		// 3. connect node
		Node n1 = cg.getNewConNode();
		cg.addConNode(n1);
		
		// 4. upward link (in -> con)
		for (Node obIn : cg.inList) {
			obIn.upward(n1);
		}
		
		// 5. upward link (con -> out)
		n1.upward(obOut);
		
		printDot();
		
	}

	public void merge() {
		System.out.println("CogStruct.merge()");
	}
	
	/* 
	 * Out node �� 1�� �����ϰ� in node ����
	 */
	public void adjust() {
		System.out.println("CogStruct.adjust()");
		
		Calc c = new Calc();
		c.calcWeight(cg);
		
		printDot();
	}
	
	public void recog() {
		System.out.println("CogStruct.calc()");
		
		Calc c = new Calc();
		c.calcPercept(cg, part.senseList);
	}
	
	public void save() {
		System.out.println("CogStruct.calc()");
	}
	
	public void printDot() {
		Print p = new Print();
		p.printDot(cg);
	}
}
